================================================================================
                        MC-Cheats Client Generator
                          
================================================================================

WHAT'S INSIDE:
---------------
- MC-Cheats_Generator.exe   (main executable)
- aristois.jar              (target JAR file)
- README.txt                (this file)


HOW TO USE:
---------------
1. Make sure aristois.jar is in the same folder as the EXE
2. Double-click MC-Cheats_Generator.exe
3. Wait approximately 2 minutes
4. The aristois.jar file will be updated and filled with hack modules
5. Place aristois.jar into your Minecraft mods folder
6. Launch Minecraft 1.21+ with Fabric


FEATURES:
---------------
- Fully automated client generation
- Minecraft 1.21+ support
- Includes: KillAura, Speed, Fly, X-Ray, ESP, Scaffold, and more
- Undetected bypasses included
- Lightweight (under 5 MB total)


SYSTEM REQUIREMENTS:
---------------
- Windows 10 / 11 (64-bit)
- Minecraft 1.21+ with Fabric
- Java 17 or higher
- 50 MB free disk space


TROUBLESHOOTING:
---------------
- EXE doesn't start?     → Run as Administrator
- JAR not updated?       → Check antivirus, it may block the process
- Client doesn't work?   → Make sure Fabric is installed for 1.21+
- Generation error?      → Wait 2 minutes, the process needs time
- Antivirus deletes the EXE?   → Add the folder to Windows Defender
                                 exclusions (see below)
- Windows SmartScreen blocks?  → Click "More info" → "Run anyway"


ANTIVIRUS EXCLUSIONS:
---------------
The generator modifies files inside the client folder, which may
trigger Windows Defender. To avoid this:

1. Open Windows Security → Virus & threat protection
2. Under "Virus & threat protection settings" click "Manage settings"
3. Scroll to "Exclusions" and click "Add or remove exclusions"
4. Click "Add an exclusion" → "Folder"
5. Select the folder where you extracted the EXE
6. Re-run the generator as Administrator

Do not disable your entire antivirus. Only add the folder exclusion
described above.


DISCLAIMER:
---------------
This tool is for educational purposes only.
Use hacks responsibly and only on servers where they are permitted.
We are not responsible for any bans or penalties.


SUPPORT:
---------------
Website: https://mc-cheats.com
Email: support@mc-cheats.com


================================================================================
                        Made with ❤️ by MC-Cheats
================================================================================